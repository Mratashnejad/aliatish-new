pg_dump: error: could not translate host name "Aliatish.db" to address: Name or service not known
